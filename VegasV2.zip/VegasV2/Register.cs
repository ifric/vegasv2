﻿using SafeGuard;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VegasV2
{
    public partial class Register : Form
    {
        public Register()
        {
            InitializeComponent();
        }

        private void iconButton2_Click(object sender, EventArgs e)
        {
            //Here, once register is successfull you can login automatically and show your main form
            ResponseInformation.registerinfo = ClientFunctions.Register(userTB.Text, passTB.Text, tokenTB.Text,
            emailTB.Text, ProgramInformation.ProgramId);
            if (!ResponseInformation.registerinfo.Failure)
            {
                //Here we commense the login method
                ResponseInformation.loginresponse = ClientFunctions.Login(userTB.Text, passTB.Text, ProgramInformation.ProgramId);
                if (ResponseInformation.loginresponse.Failure)
                {
                    MessageBox.Show(ResponseInformation.loginresponse.Message);
                }
                else
                {
                    MessageBox.Show(ResponseInformation.loginresponse.Message);
                    ResponseInformation.Password = passTB.Text;
                    this.Hide();
                    Form1 frmMain = new Form1();
                    frmMain.ShowDialog();
                    this.Close();
                }
            }
            else
            {
                MessageBox.Show(ResponseInformation.registerinfo.Message);
            }
        }

        private void iconButton1_Click(object sender, EventArgs e)
        {
            Form1 main = new Form1();
            main.Show();
            this.Hide();
        }
    }
}
