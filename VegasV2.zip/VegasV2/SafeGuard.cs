﻿using SafeGuard;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SafeGuard
{
    internal static class Update
    {
        internal static string version = "1.0";
        internal static void update()
        {
            ClientFunctions.AutoUpdate(version, ProgramInformation.ProgramId);
        }
    }
    internal static class ResponseInformation
    {
        internal static string Password;
        internal static LoginResponse loginresponse;
        internal static RegisterInformationObject registerinfo;
        internal static Count count;
    }
    internal static class ProgramInformation
    {
        internal static string ProgramId = "eb37fda5-7131-43bf-8ad5-494174dabe0d";
    }
    internal static class SafeGuardTitle
    {
        public static string safeguardtitle = "SafeGuardAuth.us";
    }
    internal class SafeCheck
    {
        internal static string CurrentDllMD5 = "AA88E613FFA57DD5361032348DC4AF9A";
        internal static string CurrentDllSHA1 = "F4652E18B2B5CA43B45580F71AC7A298AA5D831E";
        internal static string CurrentDllSHA256 = "5DF82BA08026D3C13F5D04999C6738D90A3CF68215F88F34D9C27CABAA06E3B4";
        internal static string CurrentDllSize = "5838336";

        internal static string CurrentNewtonSoftMD5 = "6815034209687816D8CF401877EC8133";
        internal static string CurrentNewtonSoftSHA1 = "1248142EB45EED3BEB0D9A2D3B8BED5FE2569B10";
        internal static string CurrentNewtonSoftSHA256 = "7F912B28A07C226E0BE3ACFB2F57F050538ABA0100FA1F0BF2C39F1A1F1DA814";
        internal static string CurrentNewtonSoftSize = "700336";
        internal static void Md5Check()
        {
            if (ComputeHash($"{AppDomain.CurrentDomain.BaseDirectory}SafeGuard.dll", "MD5") != CurrentDllMD5)
            {
                MessageBox.Show("Invalid SafeGuard.dll. Exiting Program.", SafeGuardTitle.safeguardtitle);
                Environment.Exit(2134);
            }
            if (ComputeHash($"{AppDomain.CurrentDomain.BaseDirectory}SafeGuard.dll", "SHA1") != CurrentDllSHA1)
            {
                MessageBox.Show("Invalid SafeGuard.dll. Exiting Program.", SafeGuardTitle.safeguardtitle);
                Environment.Exit(2134);
            }
            if (ComputeHash($"{AppDomain.CurrentDomain.BaseDirectory}SafeGuard.dll", "SHA256") != CurrentDllSHA256)
            {
                MessageBox.Show("Invalid SafeGuard.dll. Exiting Program.", SafeGuardTitle.safeguardtitle);
                Environment.Exit(2134);
            }
            if (ComputeHash($"{AppDomain.CurrentDomain.BaseDirectory}SafeGuard.dll", "SIZE") != CurrentDllSize)
            {
                MessageBox.Show("Invalid SafeGuard.dll. Exiting Program.", SafeGuardTitle.safeguardtitle);
                Environment.Exit(2134);
            }

            if (ComputeHash($"{AppDomain.CurrentDomain.BaseDirectory}Newtonsoft.Json.dll", "MD5") != CurrentNewtonSoftMD5)
            {
                MessageBox.Show("Invalid Newtonsoft.Json.dll. Exiting Program.", SafeGuardTitle.safeguardtitle);
                Environment.Exit(2134);
            }
            if (ComputeHash($"{AppDomain.CurrentDomain.BaseDirectory}Newtonsoft.Json.dll", "SHA1") != CurrentNewtonSoftSHA1)
            {
                MessageBox.Show("Invalid Newtonsoft.Json.dll. Exiting Program.", SafeGuardTitle.safeguardtitle);
                Environment.Exit(2134);
            }
            if (ComputeHash($"{AppDomain.CurrentDomain.BaseDirectory}Newtonsoft.Json.dll", "SHA256") != CurrentNewtonSoftSHA256)
            {
                MessageBox.Show("Invalid Newtonsoft.Json.dll. Exiting Program.", SafeGuardTitle.safeguardtitle);
                Environment.Exit(2134);
            }
            if (ComputeHash($"{AppDomain.CurrentDomain.BaseDirectory}Newtonsoft.Json.dll", "SIZE") != CurrentNewtonSoftSize)
            {
                MessageBox.Show("Invalid Newtonsoft.Json.dll. Exiting Program.", SafeGuardTitle.safeguardtitle);
                Environment.Exit(2134);
            }
        }

        internal static string ComputeHash(string s, string hashtype)
        {
            switch (hashtype)
            {
                case "MD5":
                    using (var md5 = MD5.Create())
                    {
                        try
                        {
                            using (var stream = File.OpenRead(s))
                            {
                                byte[] hash = md5.ComputeHash(stream);
                                StringBuilder sb = new StringBuilder();
                                for (int i = 0; i < hash.Length; i++)
                                {
                                    sb.Append(hash[i].ToString("X2"));
                                }

                                return sb.ToString();
                            }
                        }
                        catch
                        {
                            return "MD5 Error";
                        }
                    }
                case "SHA1":
                    using (var sha1 = SHA1.Create())
                    {
                        try
                        {
                            using (var stream = File.OpenRead(s))
                            {
                                byte[] hash = sha1.ComputeHash(stream);
                                StringBuilder sb = new StringBuilder();
                                for (int i = 0; i < hash.Length; i++)
                                {
                                    sb.Append(hash[i].ToString("X2"));
                                }

                                return sb.ToString();
                            }
                        }
                        catch
                        {
                            return "SHA1 Error";
                        }

                    }
                case "SHA256":
                    using (var sha256 = SHA256.Create())
                    {
                        try
                        {
                            using (var stream = File.OpenRead(s))
                            {
                                byte[] hash = sha256.ComputeHash(stream);
                                StringBuilder sb = new StringBuilder();
                                for (int i = 0; i < hash.Length; i++)
                                {
                                    sb.Append(hash[i].ToString("X2"));
                                }

                                return sb.ToString();
                            }
                        }
                        catch
                        {
                            return "SHA256 Error";
                        }
                    }
                case "SIZE":
                    try
                    {
                        using (var stream = File.OpenRead(s))
                        {
                            long length = new System.IO.FileInfo(s).Length;
                            return length.ToString();
                        }
                    }
                    catch
                    {
                        return "File Size Error";
                    }
                default:
                    return "Invalid Type";
            }
        }
    }
}
