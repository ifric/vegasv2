﻿
namespace VegasV2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties33 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties34 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties35 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties36 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties37 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties38 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties39 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties40 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            this.bunifuLabel1 = new Bunifu.UI.WinForms.BunifuLabel();
            this.label5 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.iconButton2 = new FontAwesome.Sharp.IconButton();
            this.iconButton1 = new FontAwesome.Sharp.IconButton();
            this.bunifuPanel1 = new Bunifu.UI.WinForms.BunifuPanel();
            this.label2 = new System.Windows.Forms.Label();
            this.iconPictureBox5 = new FontAwesome.Sharp.IconPictureBox();
            this.passTB = new Bunifu.UI.WinForms.BunifuTextBox();
            this.userTB = new Bunifu.UI.WinForms.BunifuTextBox();
            this.bunifuPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox5)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuLabel1
            // 
            this.bunifuLabel1.AllowParentOverrides = false;
            this.bunifuLabel1.AutoEllipsis = false;
            this.bunifuLabel1.Cursor = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel1.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel1.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel1.ForeColor = System.Drawing.Color.Gray;
            this.bunifuLabel1.Location = new System.Drawing.Point(34, 81);
            this.bunifuLabel1.Name = "bunifuLabel1";
            this.bunifuLabel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel1.Size = new System.Drawing.Size(75, 19);
            this.bunifuLabel1.TabIndex = 25;
            this.bunifuLabel1.Text = "Username";
            this.bunifuLabel1.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel1.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Gray;
            this.label5.Location = new System.Drawing.Point(30, 174);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(81, 19);
            this.label5.TabIndex = 145;
            this.label5.Text = "Password";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox1.ForeColor = System.Drawing.Color.MediumSlateBlue;
            this.checkBox1.Location = new System.Drawing.Point(34, 256);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(134, 23);
            this.checkBox1.TabIndex = 148;
            this.checkBox1.Text = "Remember Me";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // iconButton2
            // 
            this.iconButton2.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.iconButton2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.iconButton2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.iconButton2.ForeColor = System.Drawing.Color.White;
            this.iconButton2.IconChar = FontAwesome.Sharp.IconChar.None;
            this.iconButton2.IconColor = System.Drawing.Color.Black;
            this.iconButton2.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton2.Location = new System.Drawing.Point(34, 348);
            this.iconButton2.Name = "iconButton2";
            this.iconButton2.Size = new System.Drawing.Size(395, 40);
            this.iconButton2.TabIndex = 147;
            this.iconButton2.Text = "Register";
            this.iconButton2.UseVisualStyleBackColor = false;
            this.iconButton2.Click += new System.EventHandler(this.iconButton2_Click);
            // 
            // iconButton1
            // 
            this.iconButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.iconButton1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.iconButton1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.iconButton1.ForeColor = System.Drawing.Color.White;
            this.iconButton1.IconChar = FontAwesome.Sharp.IconChar.None;
            this.iconButton1.IconColor = System.Drawing.Color.Black;
            this.iconButton1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton1.Location = new System.Drawing.Point(34, 302);
            this.iconButton1.Name = "iconButton1";
            this.iconButton1.Size = new System.Drawing.Size(395, 40);
            this.iconButton1.TabIndex = 146;
            this.iconButton1.Text = "Login";
            this.iconButton1.UseVisualStyleBackColor = false;
            this.iconButton1.Click += new System.EventHandler(this.iconButton1_Click);
            // 
            // bunifuPanel1
            // 
            this.bunifuPanel1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuPanel1.BackgroundImage")));
            this.bunifuPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuPanel1.BorderColor = System.Drawing.Color.Transparent;
            this.bunifuPanel1.BorderRadius = 3;
            this.bunifuPanel1.BorderThickness = 1;
            this.bunifuPanel1.Controls.Add(this.label2);
            this.bunifuPanel1.Controls.Add(this.iconPictureBox5);
            this.bunifuPanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.bunifuPanel1.Location = new System.Drawing.Point(0, 0);
            this.bunifuPanel1.Name = "bunifuPanel1";
            this.bunifuPanel1.ShowBorders = true;
            this.bunifuPanel1.Size = new System.Drawing.Size(466, 45);
            this.bunifuPanel1.TabIndex = 26;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label2.Font = new System.Drawing.Font("Bahnschrift", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(59, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 25);
            this.label2.TabIndex = 9;
            this.label2.Text = "Login";
            // 
            // iconPictureBox5
            // 
            this.iconPictureBox5.BackColor = System.Drawing.Color.Transparent;
            this.iconPictureBox5.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.iconPictureBox5.IconChar = FontAwesome.Sharp.IconChar.AddressCard;
            this.iconPictureBox5.IconColor = System.Drawing.Color.WhiteSmoke;
            this.iconPictureBox5.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox5.IconSize = 59;
            this.iconPictureBox5.Location = new System.Drawing.Point(0, -2);
            this.iconPictureBox5.Name = "iconPictureBox5";
            this.iconPictureBox5.Size = new System.Drawing.Size(59, 60);
            this.iconPictureBox5.TabIndex = 8;
            this.iconPictureBox5.TabStop = false;
            // 
            // passTB
            // 
            this.passTB.AcceptsReturn = false;
            this.passTB.AcceptsTab = false;
            this.passTB.AnimationSpeed = 200;
            this.passTB.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.passTB.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.passTB.AutoSizeHeight = true;
            this.passTB.BackColor = System.Drawing.Color.Transparent;
            this.passTB.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("passTB.BackgroundImage")));
            this.passTB.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.passTB.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.passTB.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.passTB.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(18)))), ((int)(((byte)(30)))));
            this.passTB.BorderRadius = 1;
            this.passTB.BorderThickness = 1;
            this.passTB.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.passTB.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.passTB.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.passTB.DefaultText = "";
            this.passTB.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.passTB.ForeColor = System.Drawing.Color.White;
            this.passTB.HideSelection = true;
            this.passTB.IconLeft = null;
            this.passTB.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.passTB.IconPadding = 10;
            this.passTB.IconRight = null;
            this.passTB.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.passTB.Lines = new string[0];
            this.passTB.Location = new System.Drawing.Point(34, 196);
            this.passTB.MaxLength = 32767;
            this.passTB.MinimumSize = new System.Drawing.Size(1, 1);
            this.passTB.Modified = false;
            this.passTB.Multiline = false;
            this.passTB.Name = "passTB";
            stateProperties33.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties33.FillColor = System.Drawing.Color.Empty;
            stateProperties33.ForeColor = System.Drawing.Color.Empty;
            stateProperties33.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.passTB.OnActiveState = stateProperties33;
            stateProperties34.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties34.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties34.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties34.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.passTB.OnDisabledState = stateProperties34;
            stateProperties35.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties35.FillColor = System.Drawing.Color.Empty;
            stateProperties35.ForeColor = System.Drawing.Color.Empty;
            stateProperties35.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.passTB.OnHoverState = stateProperties35;
            stateProperties36.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(18)))), ((int)(((byte)(30)))));
            stateProperties36.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            stateProperties36.ForeColor = System.Drawing.Color.White;
            stateProperties36.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.passTB.OnIdleState = stateProperties36;
            this.passTB.Padding = new System.Windows.Forms.Padding(3);
            this.passTB.PasswordChar = '\0';
            this.passTB.PlaceholderForeColor = System.Drawing.Color.Gray;
            this.passTB.PlaceholderText = "";
            this.passTB.ReadOnly = false;
            this.passTB.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.passTB.SelectedText = "";
            this.passTB.SelectionLength = 0;
            this.passTB.SelectionStart = 0;
            this.passTB.ShortcutsEnabled = true;
            this.passTB.Size = new System.Drawing.Size(395, 44);
            this.passTB.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.passTB.TabIndex = 24;
            this.passTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.passTB.TextMarginBottom = 0;
            this.passTB.TextMarginLeft = 3;
            this.passTB.TextMarginTop = 0;
            this.passTB.TextPlaceholder = "";
            this.passTB.UseSystemPasswordChar = false;
            this.passTB.WordWrap = true;
            // 
            // userTB
            // 
            this.userTB.AcceptsReturn = false;
            this.userTB.AcceptsTab = false;
            this.userTB.AnimationSpeed = 200;
            this.userTB.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.userTB.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.userTB.AutoSizeHeight = true;
            this.userTB.BackColor = System.Drawing.Color.Transparent;
            this.userTB.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("userTB.BackgroundImage")));
            this.userTB.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.userTB.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.userTB.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.userTB.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(18)))), ((int)(((byte)(30)))));
            this.userTB.BorderRadius = 1;
            this.userTB.BorderThickness = 1;
            this.userTB.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.userTB.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.userTB.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.userTB.DefaultText = "";
            this.userTB.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.userTB.ForeColor = System.Drawing.Color.White;
            this.userTB.HideSelection = true;
            this.userTB.IconLeft = null;
            this.userTB.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.userTB.IconPadding = 10;
            this.userTB.IconRight = null;
            this.userTB.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.userTB.Lines = new string[0];
            this.userTB.Location = new System.Drawing.Point(34, 106);
            this.userTB.MaxLength = 32767;
            this.userTB.MinimumSize = new System.Drawing.Size(1, 1);
            this.userTB.Modified = false;
            this.userTB.Multiline = false;
            this.userTB.Name = "userTB";
            stateProperties37.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties37.FillColor = System.Drawing.Color.Empty;
            stateProperties37.ForeColor = System.Drawing.Color.Empty;
            stateProperties37.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.userTB.OnActiveState = stateProperties37;
            stateProperties38.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties38.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties38.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties38.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.userTB.OnDisabledState = stateProperties38;
            stateProperties39.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties39.FillColor = System.Drawing.Color.Empty;
            stateProperties39.ForeColor = System.Drawing.Color.Empty;
            stateProperties39.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.userTB.OnHoverState = stateProperties39;
            stateProperties40.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(18)))), ((int)(((byte)(30)))));
            stateProperties40.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            stateProperties40.ForeColor = System.Drawing.Color.White;
            stateProperties40.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.userTB.OnIdleState = stateProperties40;
            this.userTB.Padding = new System.Windows.Forms.Padding(3);
            this.userTB.PasswordChar = '\0';
            this.userTB.PlaceholderForeColor = System.Drawing.Color.Gray;
            this.userTB.PlaceholderText = "";
            this.userTB.ReadOnly = false;
            this.userTB.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.userTB.SelectedText = "";
            this.userTB.SelectionLength = 0;
            this.userTB.SelectionStart = 0;
            this.userTB.ShortcutsEnabled = true;
            this.userTB.Size = new System.Drawing.Size(395, 45);
            this.userTB.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.userTB.TabIndex = 23;
            this.userTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.userTB.TextMarginBottom = 0;
            this.userTB.TextMarginLeft = 3;
            this.userTB.TextMarginTop = 0;
            this.userTB.TextPlaceholder = "";
            this.userTB.UseSystemPasswordChar = false;
            this.userTB.WordWrap = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(22)))), ((int)(((byte)(22)))));
            this.ClientSize = new System.Drawing.Size(466, 429);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.iconButton2);
            this.Controls.Add(this.iconButton1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.bunifuPanel1);
            this.Controls.Add(this.bunifuLabel1);
            this.Controls.Add(this.passTB);
            this.Controls.Add(this.userTB);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Vegas";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.bunifuPanel1.ResumeLayout(false);
            this.bunifuPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox5)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.UI.WinForms.BunifuTextBox userTB;
        private Bunifu.UI.WinForms.BunifuTextBox passTB;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel1;
        private Bunifu.UI.WinForms.BunifuPanel bunifuPanel1;
        private System.Windows.Forms.Label label2;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox5;
        private System.Windows.Forms.Label label5;
        private FontAwesome.Sharp.IconButton iconButton1;
        private FontAwesome.Sharp.IconButton iconButton2;
        private System.Windows.Forms.CheckBox checkBox1;
    }
}

