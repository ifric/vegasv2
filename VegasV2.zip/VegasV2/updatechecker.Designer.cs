﻿
namespace VegasV2
{
    partial class updatechecker
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.upddateTB = new System.Windows.Forms.TextBox();
            this.cooldowninfo = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // upddateTB
            // 
            this.upddateTB.Location = new System.Drawing.Point(1, 0);
            this.upddateTB.Name = "upddateTB";
            this.upddateTB.Size = new System.Drawing.Size(230, 20);
            this.upddateTB.TabIndex = 0;
            this.upddateTB.Text = "2.0";
            this.upddateTB.Visible = false;
            // 
            // cooldowninfo
            // 
            this.cooldowninfo.AutoSize = true;
            this.cooldowninfo.Font = new System.Drawing.Font("Bahnschrift", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cooldowninfo.ForeColor = System.Drawing.Color.MediumSlateBlue;
            this.cooldowninfo.Location = new System.Drawing.Point(63, 23);
            this.cooldowninfo.Name = "cooldowninfo";
            this.cooldowninfo.Size = new System.Drawing.Size(225, 25);
            this.cooldowninfo.TabIndex = 12;
            this.cooldowninfo.Text = "Checking for updates...";
            // 
            // updatechecker
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(22)))), ((int)(((byte)(22)))));
            this.ClientSize = new System.Drawing.Size(365, 60);
            this.Controls.Add(this.cooldowninfo);
            this.Controls.Add(this.upddateTB);
            this.Name = "updatechecker";
            this.Text = "Vegas";
            this.Load += new System.EventHandler(this.updatechecker_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox upddateTB;
        private System.Windows.Forms.Label cooldowninfo;
    }
}