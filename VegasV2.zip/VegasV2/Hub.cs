﻿using SafeGuard;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Work.discord;

namespace VegasV2
{
    public partial class Hub : Form
    {
        private DiscordRpc.EventHandlers handlers;
        private DiscordRpc.RichPresence presence;
        public Hub()
        {
            InitializeComponent();
        }

        private void iconPictureBox3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Coming Soon!");
        }

        private void iconPictureBox1_Click(object sender, EventArgs e)
        {
            home1.Visible = true;
            attack1.Visible = false;
        }

        private void iconPictureBox2_Click(object sender, EventArgs e)
        {
            attack1.Visible = true;
            home1.Visible = false;
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Hub_Load(object sender, EventArgs e)
        {
            this.handlers = default(DiscordRpc.EventHandlers);
            DiscordRpc.Initialize("883757615694356550", ref this.handlers, true, null);
            this.handlers = default(DiscordRpc.EventHandlers);
            DiscordRpc.Initialize("883757615694356550", ref this.handlers, true, null);
            this.presence.details = "Version 2.2";
            this.presence.state = $"{ResponseInformation.loginresponse.UserName}";
            this.presence.largeImageKey = "logo";
            this.presence.smallImageKey = "logo2";
            this.presence.largeImageText = ("Dm a$al1#3767 to cop");
            this.presence.smallImageText = "";
            this.presence.startTimestamp = DateTimeOffset.Now.ToUnixTimeSeconds();
            DiscordRpc.UpdatePresence(ref this.presence);
        }

        private void attack1_Load(object sender, EventArgs e)
        {

        }
    }
}
