﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VegasV2
{
    public partial class updatechecker : Form
    {
        public updatechecker()
        {
            InitializeComponent();
        }

        private void updatechecker_Load(object sender, EventArgs e)
        {
            if (upddateTB.Text == "2.0")

            {
                MessageBox.Show("No update detected");
                Form1 main = new Form1();
                main.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Update detected, please download it!");
                System.Diagnostics.Process.Start("https://pastebin.com/raw/MJgLy3CR");
            }
        }
    }
}
