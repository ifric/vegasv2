﻿using SafeGuard;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VegasV2.UserControls
{
    public partial class Home : UserControl
    {
        public Home()
        {
            InitializeComponent();
        }

        private void siticoneCircleButton1_Click(object sender, EventArgs e)
        {

        }

        private void Home_Load(object sender, EventArgs e)
        {
            ResponseInformation.count = DeveloperFunctions.CountCall(ProgramInformation.ProgramId);
            username.Text = $"{ResponseInformation.loginresponse.UserName}";
            apis.Text = $"{ResponseInformation.count.BotnetCount}";
            totalusers.Text = $"{ResponseInformation.count.UserCount}";





            switch (ResponseInformation.loginresponse.Level)
            {
                case 1:
                    userlevel.Text = "Bronze";
                    usercons.Text = "1";
                    usertime.Text = "300";
                    uservip.Text = "False";
                    break;
                case 2:
                    userlevel.Text = "Silver";
                    usercons.Text = "2";
                    usertime.Text = "600";
                    uservip.Text = "False";
                    break;
                case 3:
                    userlevel.Text = "Gold";
                    usercons.Text = "3";
                    usertime.Text = "800";
                    uservip.Text = "True";
                    break;
                case 4:
                    userlevel.Text = "Platinium";
                    usercons.Text = "3";
                    usertime.Text = "1200";
                    uservip.Text = "True";
                    break;
            }
        }

        private void label7_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://discord.gg/aUHs9tdbPm");
        }

        private void iconPictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
