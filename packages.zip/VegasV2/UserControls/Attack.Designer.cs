﻿
namespace VegasV2.UserControls
{
    partial class Attack
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Attack));
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties13 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties14 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties15 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties16 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties17 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties18 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties19 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties20 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties21 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties22 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties23 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties24 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.siticoneProgressBar1 = new Siticone.UI.WinForms.SiticoneProgressBar();
            this.btnStart = new FontAwesome.Sharp.IconButton();
            this.label5 = new System.Windows.Forms.Label();
            this.methodsTB = new Siticone.UI.WinForms.SiticoneComboBox();
            this.servers = new Siticone.UI.WinForms.SiticoneComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.timeTB = new Bunifu.UI.WinForms.BunifuTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.portTB = new Bunifu.UI.WinForms.BunifuTextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.ipTB = new Bunifu.UI.WinForms.BunifuTextBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.iconPictureBox5 = new FontAwesome.Sharp.IconPictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.iconButton4 = new FontAwesome.Sharp.IconButton();
            this.iconButton3 = new FontAwesome.Sharp.IconButton();
            this.iconButton2 = new FontAwesome.Sharp.IconButton();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.iconPictureBox2 = new FontAwesome.Sharp.IconPictureBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.lblScreen = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.iconPictureBox1 = new FontAwesome.Sharp.IconPictureBox();
            this.level1cooldown = new System.Windows.Forms.Timer(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.iconButton1 = new FontAwesome.Sharp.IconButton();
            this.panel1.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox5)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox2)).BeginInit();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(22)))), ((int)(((byte)(22)))));
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.siticoneProgressBar1);
            this.panel1.Controls.Add(this.btnStart);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.methodsTB);
            this.panel1.Controls.Add(this.servers);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.timeTB);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.portTB);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.ipTB);
            this.panel1.Controls.Add(this.panel6);
            this.panel1.Location = new System.Drawing.Point(20, 30);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(438, 383);
            this.panel1.TabIndex = 20;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Gray;
            this.label7.Location = new System.Drawing.Point(17, 261);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(81, 19);
            this.label7.TabIndex = 149;
            this.label7.Text = "Cooldown";
            // 
            // siticoneProgressBar1
            // 
            this.siticoneProgressBar1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.siticoneProgressBar1.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
            this.siticoneProgressBar1.Location = new System.Drawing.Point(21, 283);
            this.siticoneProgressBar1.Name = "siticoneProgressBar1";
            this.siticoneProgressBar1.ProgressColor = System.Drawing.Color.DarkSlateBlue;
            this.siticoneProgressBar1.ProgressColor2 = System.Drawing.Color.DarkSlateBlue;
            this.siticoneProgressBar1.ShadowDecoration.Parent = this.siticoneProgressBar1;
            this.siticoneProgressBar1.Size = new System.Drawing.Size(403, 31);
            this.siticoneProgressBar1.TabIndex = 148;
            this.siticoneProgressBar1.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            // 
            // btnStart
            // 
            this.btnStart.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnStart.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnStart.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.btnStart.ForeColor = System.Drawing.Color.White;
            this.btnStart.IconChar = FontAwesome.Sharp.IconChar.None;
            this.btnStart.IconColor = System.Drawing.Color.Black;
            this.btnStart.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnStart.Location = new System.Drawing.Point(21, 330);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(403, 40);
            this.btnStart.TabIndex = 147;
            this.btnStart.Text = "Attack";
            this.btnStart.UseVisualStyleBackColor = false;
            this.btnStart.Click += new System.EventHandler(this.AttackButton_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Gray;
            this.label5.Location = new System.Drawing.Point(196, 197);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(62, 19);
            this.label5.TabIndex = 36;
            this.label5.Text = "Method";
            // 
            // methodsTB
            // 
            this.methodsTB.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.methodsTB.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.methodsTB.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.methodsTB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.methodsTB.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.methodsTB.FocusedColor = System.Drawing.Color.White;
            this.methodsTB.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.methodsTB.ForeColor = System.Drawing.Color.White;
            this.methodsTB.FormattingEnabled = true;
            this.methodsTB.HoveredState.Parent = this.methodsTB;
            this.methodsTB.ItemHeight = 30;
            this.methodsTB.ItemsAppearance.Parent = this.methodsTB;
            this.methodsTB.Location = new System.Drawing.Point(200, 218);
            this.methodsTB.Name = "methodsTB";
            this.methodsTB.ShadowDecoration.Parent = this.methodsTB;
            this.methodsTB.Size = new System.Drawing.Size(224, 36);
            this.methodsTB.TabIndex = 35;
            this.methodsTB.SelectedIndexChanged += new System.EventHandler(this.methodsTB_SelectedIndexChanged);
            // 
            // servers
            // 
            this.servers.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.servers.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.servers.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.servers.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.servers.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.servers.FocusedColor = System.Drawing.Color.White;
            this.servers.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.servers.ForeColor = System.Drawing.Color.White;
            this.servers.FormattingEnabled = true;
            this.servers.HoveredState.Parent = this.servers;
            this.servers.ItemHeight = 30;
            this.servers.Items.AddRange(new object[] {
            "ORPHIC",
            "STORM",
            "SMOKEY",
            "GOLDEN",
            "TRIVE",
            "HOME-HOLDER"});
            this.servers.ItemsAppearance.Parent = this.servers;
            this.servers.Location = new System.Drawing.Point(21, 218);
            this.servers.Name = "servers";
            this.servers.ShadowDecoration.Parent = this.servers;
            this.servers.Size = new System.Drawing.Size(153, 36);
            this.servers.TabIndex = 34;
            this.servers.SelectedIndexChanged += new System.EventHandler(this.servers_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Gray;
            this.label4.Location = new System.Drawing.Point(17, 196);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 19);
            this.label4.TabIndex = 33;
            this.label4.Text = "Server";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Gray;
            this.label3.Location = new System.Drawing.Point(15, 126);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 19);
            this.label3.TabIndex = 31;
            this.label3.Text = "Time";
            // 
            // timeTB
            // 
            this.timeTB.AcceptsReturn = false;
            this.timeTB.AcceptsTab = false;
            this.timeTB.AnimationSpeed = 200;
            this.timeTB.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.timeTB.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.timeTB.AutoSizeHeight = true;
            this.timeTB.BackColor = System.Drawing.Color.Transparent;
            this.timeTB.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("timeTB.BackgroundImage")));
            this.timeTB.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.timeTB.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.timeTB.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.timeTB.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(18)))), ((int)(((byte)(30)))));
            this.timeTB.BorderRadius = 1;
            this.timeTB.BorderThickness = 1;
            this.timeTB.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.timeTB.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.timeTB.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.timeTB.DefaultText = "";
            this.timeTB.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.timeTB.ForeColor = System.Drawing.Color.White;
            this.timeTB.HideSelection = true;
            this.timeTB.IconLeft = null;
            this.timeTB.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.timeTB.IconPadding = 10;
            this.timeTB.IconRight = null;
            this.timeTB.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.timeTB.Lines = new string[0];
            this.timeTB.Location = new System.Drawing.Point(16, 148);
            this.timeTB.MaxLength = 32767;
            this.timeTB.MinimumSize = new System.Drawing.Size(1, 1);
            this.timeTB.Modified = false;
            this.timeTB.Multiline = false;
            this.timeTB.Name = "timeTB";
            stateProperties13.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties13.FillColor = System.Drawing.Color.Empty;
            stateProperties13.ForeColor = System.Drawing.Color.Empty;
            stateProperties13.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.timeTB.OnActiveState = stateProperties13;
            stateProperties14.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties14.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties14.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.timeTB.OnDisabledState = stateProperties14;
            stateProperties15.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties15.FillColor = System.Drawing.Color.Empty;
            stateProperties15.ForeColor = System.Drawing.Color.Empty;
            stateProperties15.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.timeTB.OnHoverState = stateProperties15;
            stateProperties16.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(18)))), ((int)(((byte)(30)))));
            stateProperties16.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            stateProperties16.ForeColor = System.Drawing.Color.White;
            stateProperties16.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.timeTB.OnIdleState = stateProperties16;
            this.timeTB.Padding = new System.Windows.Forms.Padding(3);
            this.timeTB.PasswordChar = '\0';
            this.timeTB.PlaceholderForeColor = System.Drawing.Color.Gray;
            this.timeTB.PlaceholderText = "";
            this.timeTB.ReadOnly = false;
            this.timeTB.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.timeTB.SelectedText = "";
            this.timeTB.SelectionLength = 0;
            this.timeTB.SelectionStart = 0;
            this.timeTB.ShortcutsEnabled = true;
            this.timeTB.Size = new System.Drawing.Size(408, 42);
            this.timeTB.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.timeTB.TabIndex = 30;
            this.timeTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.timeTB.TextMarginBottom = 0;
            this.timeTB.TextMarginLeft = 3;
            this.timeTB.TextMarginTop = 0;
            this.timeTB.TextPlaceholder = "";
            this.timeTB.UseSystemPasswordChar = false;
            this.timeTB.WordWrap = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gray;
            this.label1.Location = new System.Drawing.Point(275, 60);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 19);
            this.label1.TabIndex = 29;
            this.label1.Text = "Port";
            // 
            // portTB
            // 
            this.portTB.AcceptsReturn = false;
            this.portTB.AcceptsTab = false;
            this.portTB.AnimationSpeed = 200;
            this.portTB.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.portTB.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.portTB.AutoSizeHeight = true;
            this.portTB.BackColor = System.Drawing.Color.Transparent;
            this.portTB.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("portTB.BackgroundImage")));
            this.portTB.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.portTB.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.portTB.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.portTB.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(18)))), ((int)(((byte)(30)))));
            this.portTB.BorderRadius = 1;
            this.portTB.BorderThickness = 1;
            this.portTB.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.portTB.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.portTB.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.portTB.DefaultText = "";
            this.portTB.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.portTB.ForeColor = System.Drawing.Color.White;
            this.portTB.HideSelection = true;
            this.portTB.IconLeft = null;
            this.portTB.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.portTB.IconPadding = 10;
            this.portTB.IconRight = null;
            this.portTB.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.portTB.Lines = new string[0];
            this.portTB.Location = new System.Drawing.Point(275, 81);
            this.portTB.MaxLength = 32767;
            this.portTB.MinimumSize = new System.Drawing.Size(1, 1);
            this.portTB.Modified = false;
            this.portTB.Multiline = false;
            this.portTB.Name = "portTB";
            stateProperties17.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties17.FillColor = System.Drawing.Color.Empty;
            stateProperties17.ForeColor = System.Drawing.Color.Empty;
            stateProperties17.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.portTB.OnActiveState = stateProperties17;
            stateProperties18.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties18.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties18.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.portTB.OnDisabledState = stateProperties18;
            stateProperties19.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties19.FillColor = System.Drawing.Color.Empty;
            stateProperties19.ForeColor = System.Drawing.Color.Empty;
            stateProperties19.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.portTB.OnHoverState = stateProperties19;
            stateProperties20.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(18)))), ((int)(((byte)(30)))));
            stateProperties20.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            stateProperties20.ForeColor = System.Drawing.Color.White;
            stateProperties20.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.portTB.OnIdleState = stateProperties20;
            this.portTB.Padding = new System.Windows.Forms.Padding(3);
            this.portTB.PasswordChar = '\0';
            this.portTB.PlaceholderForeColor = System.Drawing.Color.Gray;
            this.portTB.PlaceholderText = "";
            this.portTB.ReadOnly = false;
            this.portTB.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.portTB.SelectedText = "";
            this.portTB.SelectionLength = 0;
            this.portTB.SelectionStart = 0;
            this.portTB.ShortcutsEnabled = true;
            this.portTB.Size = new System.Drawing.Size(149, 42);
            this.portTB.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.portTB.TabIndex = 28;
            this.portTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.portTB.TextMarginBottom = 0;
            this.portTB.TextMarginLeft = 3;
            this.portTB.TextMarginTop = 0;
            this.portTB.TextPlaceholder = "";
            this.portTB.UseSystemPasswordChar = false;
            this.portTB.WordWrap = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Gray;
            this.label9.Location = new System.Drawing.Point(17, 60);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(42, 19);
            this.label9.TabIndex = 27;
            this.label9.Text = "Host";
            // 
            // ipTB
            // 
            this.ipTB.AcceptsReturn = false;
            this.ipTB.AcceptsTab = false;
            this.ipTB.AnimationSpeed = 200;
            this.ipTB.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.ipTB.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.ipTB.AutoSizeHeight = true;
            this.ipTB.BackColor = System.Drawing.Color.Transparent;
            this.ipTB.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ipTB.BackgroundImage")));
            this.ipTB.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.ipTB.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.ipTB.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.ipTB.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(18)))), ((int)(((byte)(30)))));
            this.ipTB.BorderRadius = 1;
            this.ipTB.BorderThickness = 1;
            this.ipTB.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.ipTB.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.ipTB.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.ipTB.DefaultText = "";
            this.ipTB.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.ipTB.ForeColor = System.Drawing.Color.White;
            this.ipTB.HideSelection = true;
            this.ipTB.IconLeft = null;
            this.ipTB.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.ipTB.IconPadding = 10;
            this.ipTB.IconRight = null;
            this.ipTB.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.ipTB.Lines = new string[0];
            this.ipTB.Location = new System.Drawing.Point(16, 81);
            this.ipTB.MaxLength = 32767;
            this.ipTB.MinimumSize = new System.Drawing.Size(1, 1);
            this.ipTB.Modified = false;
            this.ipTB.Multiline = false;
            this.ipTB.Name = "ipTB";
            stateProperties21.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties21.FillColor = System.Drawing.Color.Empty;
            stateProperties21.ForeColor = System.Drawing.Color.Empty;
            stateProperties21.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.ipTB.OnActiveState = stateProperties21;
            stateProperties22.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties22.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties22.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties22.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.ipTB.OnDisabledState = stateProperties22;
            stateProperties23.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties23.FillColor = System.Drawing.Color.Empty;
            stateProperties23.ForeColor = System.Drawing.Color.Empty;
            stateProperties23.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.ipTB.OnHoverState = stateProperties23;
            stateProperties24.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(18)))), ((int)(((byte)(30)))));
            stateProperties24.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            stateProperties24.ForeColor = System.Drawing.Color.White;
            stateProperties24.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.ipTB.OnIdleState = stateProperties24;
            this.ipTB.Padding = new System.Windows.Forms.Padding(3);
            this.ipTB.PasswordChar = '\0';
            this.ipTB.PlaceholderForeColor = System.Drawing.Color.Gray;
            this.ipTB.PlaceholderText = "";
            this.ipTB.ReadOnly = false;
            this.ipTB.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.ipTB.SelectedText = "";
            this.ipTB.SelectionLength = 0;
            this.ipTB.SelectionStart = 0;
            this.ipTB.ShortcutsEnabled = true;
            this.ipTB.Size = new System.Drawing.Size(253, 42);
            this.ipTB.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.ipTB.TabIndex = 26;
            this.ipTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.ipTB.TextMarginBottom = 0;
            this.ipTB.TextMarginLeft = 3;
            this.ipTB.TextMarginTop = 0;
            this.ipTB.TextPlaceholder = "";
            this.ipTB.UseSystemPasswordChar = false;
            this.ipTB.WordWrap = true;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.panel6.Controls.Add(this.label2);
            this.panel6.Controls.Add(this.iconPictureBox5);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(438, 45);
            this.panel6.TabIndex = 23;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Bahnschrift", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(59, 8);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(115, 25);
            this.label2.TabIndex = 9;
            this.label2.Text = "Attack Hub";
            // 
            // iconPictureBox5
            // 
            this.iconPictureBox5.BackColor = System.Drawing.Color.Transparent;
            this.iconPictureBox5.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.iconPictureBox5.IconChar = FontAwesome.Sharp.IconChar.Wifi;
            this.iconPictureBox5.IconColor = System.Drawing.Color.WhiteSmoke;
            this.iconPictureBox5.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox5.IconSize = 59;
            this.iconPictureBox5.Location = new System.Drawing.Point(0, -5);
            this.iconPictureBox5.Name = "iconPictureBox5";
            this.iconPictureBox5.Size = new System.Drawing.Size(59, 60);
            this.iconPictureBox5.TabIndex = 8;
            this.iconPictureBox5.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(22)))), ((int)(((byte)(22)))));
            this.panel2.Controls.Add(this.iconButton4);
            this.panel2.Controls.Add(this.iconButton3);
            this.panel2.Controls.Add(this.iconButton2);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Location = new System.Drawing.Point(464, 30);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(411, 198);
            this.panel2.TabIndex = 21;
            // 
            // iconButton4
            // 
            this.iconButton4.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.iconButton4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.iconButton4.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.iconButton4.ForeColor = System.Drawing.Color.White;
            this.iconButton4.IconChar = FontAwesome.Sharp.IconChar.None;
            this.iconButton4.IconColor = System.Drawing.Color.Black;
            this.iconButton4.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton4.Location = new System.Drawing.Point(14, 148);
            this.iconButton4.Name = "iconButton4";
            this.iconButton4.Size = new System.Drawing.Size(382, 39);
            this.iconButton4.TabIndex = 152;
            this.iconButton4.Text = "Ping 1.1.1.1";
            this.iconButton4.UseVisualStyleBackColor = false;
            this.iconButton4.Click += new System.EventHandler(this.iconButton4_Click);
            // 
            // iconButton3
            // 
            this.iconButton3.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.iconButton3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.iconButton3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.iconButton3.ForeColor = System.Drawing.Color.White;
            this.iconButton3.IconChar = FontAwesome.Sharp.IconChar.None;
            this.iconButton3.IconColor = System.Drawing.Color.Black;
            this.iconButton3.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton3.Location = new System.Drawing.Point(14, 104);
            this.iconButton3.Name = "iconButton3";
            this.iconButton3.Size = new System.Drawing.Size(382, 39);
            this.iconButton3.TabIndex = 151;
            this.iconButton3.Text = "TCP Ping";
            this.iconButton3.UseVisualStyleBackColor = false;
            this.iconButton3.Click += new System.EventHandler(this.iconButton3_Click);
            // 
            // iconButton2
            // 
            this.iconButton2.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.iconButton2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.iconButton2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.iconButton2.ForeColor = System.Drawing.Color.White;
            this.iconButton2.IconChar = FontAwesome.Sharp.IconChar.None;
            this.iconButton2.IconColor = System.Drawing.Color.Black;
            this.iconButton2.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton2.Location = new System.Drawing.Point(14, 60);
            this.iconButton2.Name = "iconButton2";
            this.iconButton2.Size = new System.Drawing.Size(382, 39);
            this.iconButton2.TabIndex = 150;
            this.iconButton2.Text = "Ping";
            this.iconButton2.UseVisualStyleBackColor = false;
            this.iconButton2.Click += new System.EventHandler(this.iconButton2_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.iconPictureBox2);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(411, 45);
            this.panel3.TabIndex = 22;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Bahnschrift", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(59, 8);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(85, 25);
            this.label6.TabIndex = 9;
            this.label6.Text = "IP Tools";
            // 
            // iconPictureBox2
            // 
            this.iconPictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.iconPictureBox2.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.iconPictureBox2.IconChar = FontAwesome.Sharp.IconChar.Wrench;
            this.iconPictureBox2.IconColor = System.Drawing.Color.WhiteSmoke;
            this.iconPictureBox2.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox2.IconSize = 59;
            this.iconPictureBox2.Location = new System.Drawing.Point(0, -2);
            this.iconPictureBox2.Name = "iconPictureBox2";
            this.iconPictureBox2.Size = new System.Drawing.Size(59, 60);
            this.iconPictureBox2.TabIndex = 8;
            this.iconPictureBox2.TabStop = false;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(22)))), ((int)(((byte)(22)))));
            this.panel4.Controls.Add(this.iconButton1);
            this.panel4.Controls.Add(this.richTextBox1);
            this.panel4.Controls.Add(this.panel5);
            this.panel4.Location = new System.Drawing.Point(464, 234);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(411, 179);
            this.panel4.TabIndex = 23;
            // 
            // richTextBox1
            // 
            this.richTextBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.richTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBox1.Font = new System.Drawing.Font("Bahnschrift", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox1.ForeColor = System.Drawing.Color.White;
            this.richTextBox1.Location = new System.Drawing.Point(0, 45);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(411, 102);
            this.richTextBox1.TabIndex = 23;
            this.richTextBox1.Text = "";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.panel5.Controls.Add(this.lblScreen);
            this.panel5.Controls.Add(this.label12);
            this.panel5.Controls.Add(this.iconPictureBox1);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(411, 45);
            this.panel5.TabIndex = 22;
            // 
            // lblScreen
            // 
            this.lblScreen.Font = new System.Drawing.Font("Bahnschrift", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblScreen.ForeColor = System.Drawing.Color.White;
            this.lblScreen.Location = new System.Drawing.Point(300, 10);
            this.lblScreen.Name = "lblScreen";
            this.lblScreen.Size = new System.Drawing.Size(85, 25);
            this.lblScreen.TabIndex = 10;
            this.lblScreen.Text = "N/A";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Bahnschrift", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(59, 11);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(57, 25);
            this.label12.TabIndex = 9;
            this.label12.Text = "Logs";
            // 
            // iconPictureBox1
            // 
            this.iconPictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.iconPictureBox1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.iconPictureBox1.IconChar = FontAwesome.Sharp.IconChar.Newspaper;
            this.iconPictureBox1.IconColor = System.Drawing.Color.WhiteSmoke;
            this.iconPictureBox1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox1.IconSize = 59;
            this.iconPictureBox1.Location = new System.Drawing.Point(0, -2);
            this.iconPictureBox1.Name = "iconPictureBox1";
            this.iconPictureBox1.Size = new System.Drawing.Size(59, 60);
            this.iconPictureBox1.TabIndex = 8;
            this.iconPictureBox1.TabStop = false;
            // 
            // level1cooldown
            // 
            this.level1cooldown.Tick += new System.EventHandler(this.level1cooldown_Tick);
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.countdownTimer_Tick);
            // 
            // iconButton1
            // 
            this.iconButton1.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.iconButton1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.iconButton1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.iconButton1.ForeColor = System.Drawing.Color.White;
            this.iconButton1.IconChar = FontAwesome.Sharp.IconChar.None;
            this.iconButton1.IconColor = System.Drawing.Color.Black;
            this.iconButton1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton1.Location = new System.Drawing.Point(0, 141);
            this.iconButton1.Name = "iconButton1";
            this.iconButton1.Size = new System.Drawing.Size(411, 35);
            this.iconButton1.TabIndex = 150;
            this.iconButton1.Text = "Clear";
            this.iconButton1.UseVisualStyleBackColor = false;
            this.iconButton1.Click += new System.EventHandler(this.iconButton1_Click_1);
            // 
            // Attack
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.BackgroundImage = global::VegasV2.Properties.Resources._212197sdsed;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Attack";
            this.Size = new System.Drawing.Size(892, 475);
            this.Load += new System.EventHandler(this.Attack_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox5)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox2)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label2;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox5;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label6;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label12;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private Bunifu.UI.WinForms.BunifuTextBox timeTB;
        private System.Windows.Forms.Label label1;
        private Bunifu.UI.WinForms.BunifuTextBox portTB;
        private System.Windows.Forms.Label label9;
        private Bunifu.UI.WinForms.BunifuTextBox ipTB;
        private System.Windows.Forms.Label label5;
        private Siticone.UI.WinForms.SiticoneComboBox methodsTB;
        private Siticone.UI.WinForms.SiticoneComboBox servers;
        private Siticone.UI.WinForms.SiticoneProgressBar siticoneProgressBar1;
        private FontAwesome.Sharp.IconButton btnStart;
        private System.Windows.Forms.Label label7;
        private FontAwesome.Sharp.IconButton iconButton4;
        private FontAwesome.Sharp.IconButton iconButton3;
        private FontAwesome.Sharp.IconButton iconButton2;
        private System.Windows.Forms.Timer level1cooldown;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Label lblScreen;
        private System.Windows.Forms.Timer timer1;
        private FontAwesome.Sharp.IconButton iconButton1;
    }
}
