﻿using SafeGuard;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VegasV2.UserControls
{
    public partial class Attack : UserControl
    {
        int value;
        public Attack()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void iconButton2_Click(object sender, EventArgs e)
        {
            new Process
            {
                StartInfo =
                {
                    UseShellExecute = false,
                    FileName = "ping.exe",
                   Arguments = this.ipTB.Text + " -t"
                }
            }.Start();
        }

        private void iconButton3_Click(object sender, EventArgs e)
        {
            new Process
            {
                StartInfo =
                    {
                        UseShellExecute = false,
                        FileName = "paping.exe",
                        Arguments = this.ipTB.Text + " -p " + this.portTB.Text
                    }
            }.Start();
            string arguments = "paping.exe" + this.ipTB.Text + " -p " + this.portTB.Text;
            Process.Start("ping.exe", arguments);
        }

        private void iconButton4_Click(object sender, EventArgs e)
        {
            new Process
            {
                StartInfo =
                {
                    UseShellExecute = false,
                    FileName = "ping.exe",
                   Arguments = "1.1.1.1" + " -t"
                }
            }.Start();
        }

        private void AttackButton_Click(object sender, EventArgs e)
        {
            var response = ClientFunctions.AttackRequest(ResponseInformation.loginresponse.UserName, ResponseInformation.Password, ProgramInformation.ProgramId, ipTB.Text, portTB.Text, methodsTB.Text, timeTB.Text, false);

            
           
            timer1.Start();
            richTextBox1.Text = ipTB.Text + "│" + portTB.Text + "│" + timeTB.Text + "│" + methodsTB.Text;
            siticoneProgressBar1.Value = 0;
            //Disable Button
            btnStart.Enabled = false;
            //Attack Timer
            level1cooldown.Start();
        }

        private void level1cooldown_Tick(object sender, EventArgs e)
        {
            #region CoolDown
            int max;

            switch (ResponseInformation.loginresponse.Level)
            {
                case 1:
                    max = 600;
                    break;
                case 2:
                    max = 300;
                    break;
                case 3:
                    max = 150;
                    break;
                case 4:
                    max = 100;
                    break;
                default:
                    max = 0;
                    break;
            }
            siticoneProgressBar1.Maximum = max;

            if (siticoneProgressBar1.Value < siticoneProgressBar1.Maximum)
            {
                siticoneProgressBar1.Value = siticoneProgressBar1.Value + 1;
            }

            if (siticoneProgressBar1.Value == siticoneProgressBar1.Maximum)
            {
                level1cooldown.Stop();
                siticoneProgressBar1.Value = siticoneProgressBar1.Maximum;
                btnStart.Enabled = true;
            }
            #endregion
        }

        private void Attack_Load(object sender, EventArgs e)
        {
            
        }

        private void methodsTB_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private async void servers_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (servers.Text == "STORM")
            {
                var wc = new HttpClient();
                string Methods = await Task.Run(() => wc.GetStringAsync("https://pastebin.com/raw/3FcYr9BC"));
                string[] Methodlines = Methods.Split(new string[]
                {
                    Environment.NewLine
                }, StringSplitOptions.None);
                methodsTB.DataSource = Methodlines;
                wc.Dispose();
            }
            else if (servers.Text == "TRIVE")
            {
                var wc = new HttpClient();
                string Methods = await Task.Run(() => wc.GetStringAsync("https://pastebin.com/raw/9mLcKGjV"));
                string[] Methodlines = Methods.Split(new string[]
                {
                    Environment.NewLine
                }, StringSplitOptions.None);
                methodsTB.DataSource = Methodlines;
                wc.Dispose();
            }
            else if (servers.Text == "GOLDEN")
            {
                var wc = new HttpClient();
                string Methods = await Task.Run(() => wc.GetStringAsync("https://pastebin.com/raw/8L8FXdaq"));
                string[] Methodlines = Methods.Split(new string[]
                {
                    Environment.NewLine
                }, StringSplitOptions.None);
                methodsTB.DataSource = Methodlines;
                wc.Dispose();
            }
            else if (servers.Text == "SMOKEY")
            {
                var wc = new HttpClient();
                string Methods = await Task.Run(() => wc.GetStringAsync("https://pastebin.com/raw/cfHxFvpv"));
                string[] Methodlines = Methods.Split(new string[]
                {
                    Environment.NewLine
                }, StringSplitOptions.None);
                methodsTB.DataSource = Methodlines;
                wc.Dispose();
            }
            else if (servers.Text == "HOME-HOLDER")
            {
                var wc = new HttpClient();
                string Methods = await Task.Run(() => wc.GetStringAsync("https://pastebin.com/raw/G9AfKdrE"));
                string[] Methodlines = Methods.Split(new string[]
                {
                    Environment.NewLine
                }, StringSplitOptions.None);
                methodsTB.DataSource = Methodlines;
                wc.Dispose();
            }
            else if (servers.Text == "ORPHIC")
            {
                var wc = new HttpClient();
                string Methods = await Task.Run(() => wc.GetStringAsync("https://pastebin.com/raw/2QNvcXT0"));
                string[] Methodlines = Methods.Split(new string[]
                {
                    Environment.NewLine
                }, StringSplitOptions.None);
                methodsTB.DataSource = Methodlines;
                wc.Dispose();
            }
        }

        private void countdownTimer_Tick(object sender, EventArgs e)
        {
            timeTB.Text = (value++).ToString();
        }

        private void iconButton1_Click(object sender, EventArgs e)
        {
            
        }

        private void iconButton5_Click(object sender, EventArgs e)
        {
            
                
            
        }

        private void iconButton1_Click_1(object sender, EventArgs e)
        {
            richTextBox1.Text = "";
        }
    }
}
