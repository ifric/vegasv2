﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VegasV2.UserControls
{
    public partial class Runningattack : UserControl
    {
        public Runningattack()
        {
            InitializeComponent();
        }

        private void PastAttacksDV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Runningattack_Load(object sender, EventArgs e)
        {

        }
    }
}
