﻿
namespace VegasV2.UserControls
{
    partial class Home
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.uservip = new System.Windows.Forms.Label();
            this.iconPictureBox12 = new FontAwesome.Sharp.IconPictureBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.usercons = new System.Windows.Forms.Label();
            this.iconPictureBox11 = new FontAwesome.Sharp.IconPictureBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.userlevel = new System.Windows.Forms.Label();
            this.iconPictureBox9 = new FontAwesome.Sharp.IconPictureBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.usertime = new System.Windows.Forms.Label();
            this.iconPictureBox10 = new FontAwesome.Sharp.IconPictureBox();
            this.siticoneCirclePictureBox1 = new Siticone.UI.WinForms.SiticoneCirclePictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.iconPictureBox4 = new FontAwesome.Sharp.IconPictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.username = new System.Windows.Forms.Label();
            this.iconPictureBox13 = new FontAwesome.Sharp.IconPictureBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.apis = new System.Windows.Forms.Label();
            this.iconPictureBox3 = new FontAwesome.Sharp.IconPictureBox();
            this.panel10 = new System.Windows.Forms.Panel();
            this.totalusers = new System.Windows.Forms.Label();
            this.iconPictureBox2 = new FontAwesome.Sharp.IconPictureBox();
            this.panel9 = new System.Windows.Forms.Panel();
            this.activeapis = new System.Windows.Forms.Label();
            this.iconPictureBox1 = new FontAwesome.Sharp.IconPictureBox();
            this.panel13 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.iconPictureBox5 = new FontAwesome.Sharp.IconPictureBox();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel15 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.panel14 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.panel16 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label5 = new System.Windows.Forms.Label();
            this.panel17 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.iconPictureBox14 = new FontAwesome.Sharp.IconPictureBox();
            this.panel2.SuspendLayout();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox12)).BeginInit();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox11)).BeginInit();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox9)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.siticoneCirclePictureBox1)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox4)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox13)).BeginInit();
            this.panel8.SuspendLayout();
            this.panel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox3)).BeginInit();
            this.panel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox2)).BeginInit();
            this.panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox1)).BeginInit();
            this.panel13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox5)).BeginInit();
            this.panel12.SuspendLayout();
            this.panel15.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panel14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel16.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel17.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox14)).BeginInit();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(22)))), ((int)(((byte)(22)))));
            this.panel2.Controls.Add(this.panel7);
            this.panel2.Controls.Add(this.panel6);
            this.panel2.Controls.Add(this.panel5);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.siticoneCirclePictureBox1);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Location = new System.Drawing.Point(22, 14);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(254, 458);
            this.panel2.TabIndex = 22;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.panel7.Controls.Add(this.uservip);
            this.panel7.Controls.Add(this.iconPictureBox12);
            this.panel7.Location = new System.Drawing.Point(0, 406);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(254, 47);
            this.panel7.TabIndex = 28;
            // 
            // uservip
            // 
            this.uservip.AutoSize = true;
            this.uservip.Font = new System.Drawing.Font("Bahnschrift", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uservip.ForeColor = System.Drawing.Color.MediumSlateBlue;
            this.uservip.Location = new System.Drawing.Point(55, 11);
            this.uservip.Name = "uservip";
            this.uservip.Size = new System.Drawing.Size(43, 25);
            this.uservip.TabIndex = 9;
            this.uservip.Text = "VIP";
            // 
            // iconPictureBox12
            // 
            this.iconPictureBox12.BackColor = System.Drawing.Color.Transparent;
            this.iconPictureBox12.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.iconPictureBox12.IconChar = FontAwesome.Sharp.IconChar.Gem;
            this.iconPictureBox12.IconColor = System.Drawing.Color.WhiteSmoke;
            this.iconPictureBox12.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox12.IconSize = 45;
            this.iconPictureBox12.Location = new System.Drawing.Point(-2, 1);
            this.iconPictureBox12.Name = "iconPictureBox12";
            this.iconPictureBox12.Size = new System.Drawing.Size(49, 45);
            this.iconPictureBox12.TabIndex = 8;
            this.iconPictureBox12.TabStop = false;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.panel6.Controls.Add(this.usercons);
            this.panel6.Controls.Add(this.iconPictureBox11);
            this.panel6.Location = new System.Drawing.Point(0, 354);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(254, 48);
            this.panel6.TabIndex = 27;
            // 
            // usercons
            // 
            this.usercons.AutoSize = true;
            this.usercons.Font = new System.Drawing.Font("Bahnschrift", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.usercons.ForeColor = System.Drawing.Color.MediumSlateBlue;
            this.usercons.Location = new System.Drawing.Point(55, 12);
            this.usercons.Name = "usercons";
            this.usercons.Size = new System.Drawing.Size(67, 25);
            this.usercons.TabIndex = 9;
            this.usercons.Text = "CONS";
            // 
            // iconPictureBox11
            // 
            this.iconPictureBox11.BackColor = System.Drawing.Color.Transparent;
            this.iconPictureBox11.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.iconPictureBox11.IconChar = FontAwesome.Sharp.IconChar.Cubes;
            this.iconPictureBox11.IconColor = System.Drawing.Color.WhiteSmoke;
            this.iconPictureBox11.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox11.IconSize = 45;
            this.iconPictureBox11.Location = new System.Drawing.Point(0, 3);
            this.iconPictureBox11.Name = "iconPictureBox11";
            this.iconPictureBox11.Size = new System.Drawing.Size(49, 45);
            this.iconPictureBox11.TabIndex = 8;
            this.iconPictureBox11.TabStop = false;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.panel5.Controls.Add(this.userlevel);
            this.panel5.Controls.Add(this.iconPictureBox9);
            this.panel5.Location = new System.Drawing.Point(0, 196);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(254, 48);
            this.panel5.TabIndex = 27;
            // 
            // userlevel
            // 
            this.userlevel.AutoSize = true;
            this.userlevel.Font = new System.Drawing.Font("Bahnschrift", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.userlevel.ForeColor = System.Drawing.Color.MediumSlateBlue;
            this.userlevel.Location = new System.Drawing.Point(55, 11);
            this.userlevel.Name = "userlevel";
            this.userlevel.Size = new System.Drawing.Size(67, 25);
            this.userlevel.TabIndex = 9;
            this.userlevel.Text = "RANK";
            // 
            // iconPictureBox9
            // 
            this.iconPictureBox9.BackColor = System.Drawing.Color.Transparent;
            this.iconPictureBox9.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.iconPictureBox9.IconChar = FontAwesome.Sharp.IconChar.Crown;
            this.iconPictureBox9.IconColor = System.Drawing.Color.WhiteSmoke;
            this.iconPictureBox9.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox9.IconSize = 45;
            this.iconPictureBox9.Location = new System.Drawing.Point(0, 1);
            this.iconPictureBox9.Name = "iconPictureBox9";
            this.iconPictureBox9.Size = new System.Drawing.Size(49, 45);
            this.iconPictureBox9.TabIndex = 8;
            this.iconPictureBox9.TabStop = false;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.panel4.Controls.Add(this.usertime);
            this.panel4.Controls.Add(this.iconPictureBox10);
            this.panel4.Location = new System.Drawing.Point(0, 302);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(254, 48);
            this.panel4.TabIndex = 26;
            // 
            // usertime
            // 
            this.usertime.AutoSize = true;
            this.usertime.Font = new System.Drawing.Font("Bahnschrift", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.usertime.ForeColor = System.Drawing.Color.MediumSlateBlue;
            this.usertime.Location = new System.Drawing.Point(55, 11);
            this.usertime.Name = "usertime";
            this.usertime.Size = new System.Drawing.Size(57, 25);
            this.usertime.TabIndex = 9;
            this.usertime.Text = "TIME";
            // 
            // iconPictureBox10
            // 
            this.iconPictureBox10.BackColor = System.Drawing.Color.Transparent;
            this.iconPictureBox10.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.iconPictureBox10.IconChar = FontAwesome.Sharp.IconChar.Clock;
            this.iconPictureBox10.IconColor = System.Drawing.Color.WhiteSmoke;
            this.iconPictureBox10.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox10.IconSize = 45;
            this.iconPictureBox10.Location = new System.Drawing.Point(0, 1);
            this.iconPictureBox10.Name = "iconPictureBox10";
            this.iconPictureBox10.Size = new System.Drawing.Size(49, 45);
            this.iconPictureBox10.TabIndex = 8;
            this.iconPictureBox10.TabStop = false;
            // 
            // siticoneCirclePictureBox1
            // 
            this.siticoneCirclePictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(22)))), ((int)(((byte)(22)))));
            this.siticoneCirclePictureBox1.Image = global::VegasV2.Properties.Resources.VegasLogo;
            this.siticoneCirclePictureBox1.Location = new System.Drawing.Point(60, 51);
            this.siticoneCirclePictureBox1.Name = "siticoneCirclePictureBox1";
            this.siticoneCirclePictureBox1.ShadowDecoration.Mode = Siticone.UI.WinForms.Enums.ShadowMode.Circle;
            this.siticoneCirclePictureBox1.ShadowDecoration.Parent = this.siticoneCirclePictureBox1;
            this.siticoneCirclePictureBox1.Size = new System.Drawing.Size(139, 132);
            this.siticoneCirclePictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.siticoneCirclePictureBox1.TabIndex = 25;
            this.siticoneCirclePictureBox1.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.iconPictureBox4);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(254, 45);
            this.panel3.TabIndex = 22;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bahnschrift", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(46, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 25);
            this.label1.TabIndex = 9;
            this.label1.Text = "User Info";
            // 
            // iconPictureBox4
            // 
            this.iconPictureBox4.BackColor = System.Drawing.Color.Transparent;
            this.iconPictureBox4.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.iconPictureBox4.IconChar = FontAwesome.Sharp.IconChar.UserAlt;
            this.iconPictureBox4.IconColor = System.Drawing.Color.WhiteSmoke;
            this.iconPictureBox4.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox4.IconSize = 45;
            this.iconPictureBox4.Location = new System.Drawing.Point(0, 0);
            this.iconPictureBox4.Name = "iconPictureBox4";
            this.iconPictureBox4.Size = new System.Drawing.Size(49, 45);
            this.iconPictureBox4.TabIndex = 8;
            this.iconPictureBox4.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.panel1.Controls.Add(this.username);
            this.panel1.Controls.Add(this.iconPictureBox13);
            this.panel1.Location = new System.Drawing.Point(22, 263);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(254, 48);
            this.panel1.TabIndex = 27;
            // 
            // username
            // 
            this.username.AutoSize = true;
            this.username.Font = new System.Drawing.Font("Bahnschrift", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.username.ForeColor = System.Drawing.Color.MediumSlateBlue;
            this.username.Location = new System.Drawing.Point(55, 12);
            this.username.Name = "username";
            this.username.Size = new System.Drawing.Size(124, 25);
            this.username.TabIndex = 9;
            this.username.Text = "USERNAME";
            // 
            // iconPictureBox13
            // 
            this.iconPictureBox13.BackColor = System.Drawing.Color.Transparent;
            this.iconPictureBox13.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.iconPictureBox13.IconChar = FontAwesome.Sharp.IconChar.UserCheck;
            this.iconPictureBox13.IconColor = System.Drawing.Color.WhiteSmoke;
            this.iconPictureBox13.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox13.IconSize = 45;
            this.iconPictureBox13.Location = new System.Drawing.Point(0, 2);
            this.iconPictureBox13.Name = "iconPictureBox13";
            this.iconPictureBox13.Size = new System.Drawing.Size(49, 45);
            this.iconPictureBox13.TabIndex = 8;
            this.iconPictureBox13.TabStop = false;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(22)))), ((int)(((byte)(22)))));
            this.panel8.Controls.Add(this.panel11);
            this.panel8.Controls.Add(this.panel10);
            this.panel8.Controls.Add(this.panel9);
            this.panel8.Controls.Add(this.panel13);
            this.panel8.Location = new System.Drawing.Point(294, 17);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(564, 218);
            this.panel8.TabIndex = 29;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.panel11.Controls.Add(this.apis);
            this.panel11.Controls.Add(this.iconPictureBox3);
            this.panel11.Location = new System.Drawing.Point(3, 155);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(561, 48);
            this.panel11.TabIndex = 29;
            // 
            // apis
            // 
            this.apis.AutoSize = true;
            this.apis.Font = new System.Drawing.Font("Bahnschrift", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.apis.ForeColor = System.Drawing.Color.MediumSlateBlue;
            this.apis.Location = new System.Drawing.Point(52, 10);
            this.apis.Name = "apis";
            this.apis.Size = new System.Drawing.Size(62, 25);
            this.apis.TabIndex = 9;
            this.apis.Text = "API\'S";
            // 
            // iconPictureBox3
            // 
            this.iconPictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.iconPictureBox3.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.iconPictureBox3.IconChar = FontAwesome.Sharp.IconChar.SatelliteDish;
            this.iconPictureBox3.IconColor = System.Drawing.Color.WhiteSmoke;
            this.iconPictureBox3.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox3.IconSize = 49;
            this.iconPictureBox3.Location = new System.Drawing.Point(-3, 0);
            this.iconPictureBox3.Name = "iconPictureBox3";
            this.iconPictureBox3.Size = new System.Drawing.Size(49, 58);
            this.iconPictureBox3.TabIndex = 8;
            this.iconPictureBox3.TabStop = false;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.panel10.Controls.Add(this.totalusers);
            this.panel10.Controls.Add(this.iconPictureBox2);
            this.panel10.Location = new System.Drawing.Point(3, 105);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(561, 48);
            this.panel10.TabIndex = 29;
            // 
            // totalusers
            // 
            this.totalusers.AutoSize = true;
            this.totalusers.Font = new System.Drawing.Font("Bahnschrift", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalusers.ForeColor = System.Drawing.Color.MediumSlateBlue;
            this.totalusers.Location = new System.Drawing.Point(52, 10);
            this.totalusers.Name = "totalusers";
            this.totalusers.Size = new System.Drawing.Size(79, 25);
            this.totalusers.TabIndex = 9;
            this.totalusers.Text = "USERS";
            // 
            // iconPictureBox2
            // 
            this.iconPictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.iconPictureBox2.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.iconPictureBox2.IconChar = FontAwesome.Sharp.IconChar.UserFriends;
            this.iconPictureBox2.IconColor = System.Drawing.Color.WhiteSmoke;
            this.iconPictureBox2.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox2.IconSize = 49;
            this.iconPictureBox2.Location = new System.Drawing.Point(-3, 0);
            this.iconPictureBox2.Name = "iconPictureBox2";
            this.iconPictureBox2.Size = new System.Drawing.Size(49, 58);
            this.iconPictureBox2.TabIndex = 8;
            this.iconPictureBox2.TabStop = false;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.panel9.Controls.Add(this.activeapis);
            this.panel9.Controls.Add(this.iconPictureBox1);
            this.panel9.Location = new System.Drawing.Point(3, 51);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(561, 48);
            this.panel9.TabIndex = 28;
            // 
            // activeapis
            // 
            this.activeapis.AutoSize = true;
            this.activeapis.Font = new System.Drawing.Font("Bahnschrift", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.activeapis.ForeColor = System.Drawing.Color.MediumSlateBlue;
            this.activeapis.Location = new System.Drawing.Point(55, 10);
            this.activeapis.Name = "activeapis";
            this.activeapis.Size = new System.Drawing.Size(39, 25);
            this.activeapis.TabIndex = 9;
            this.activeapis.Text = "2.2";
            // 
            // iconPictureBox1
            // 
            this.iconPictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.iconPictureBox1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.iconPictureBox1.IconChar = FontAwesome.Sharp.IconChar.CodeBranch;
            this.iconPictureBox1.IconColor = System.Drawing.Color.WhiteSmoke;
            this.iconPictureBox1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox1.IconSize = 49;
            this.iconPictureBox1.Location = new System.Drawing.Point(0, 0);
            this.iconPictureBox1.Name = "iconPictureBox1";
            this.iconPictureBox1.Size = new System.Drawing.Size(49, 58);
            this.iconPictureBox1.TabIndex = 8;
            this.iconPictureBox1.TabStop = false;
            this.iconPictureBox1.Click += new System.EventHandler(this.iconPictureBox1_Click);
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.panel13.Controls.Add(this.label2);
            this.panel13.Controls.Add(this.iconPictureBox5);
            this.panel13.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel13.Location = new System.Drawing.Point(0, 0);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(564, 45);
            this.panel13.TabIndex = 22;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Bahnschrift", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(62, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(179, 25);
            this.label2.TabIndex = 9;
            this.label2.Text = "Panel Information";
            // 
            // iconPictureBox5
            // 
            this.iconPictureBox5.BackColor = System.Drawing.Color.Transparent;
            this.iconPictureBox5.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.iconPictureBox5.IconChar = FontAwesome.Sharp.IconChar.InfoCircle;
            this.iconPictureBox5.IconColor = System.Drawing.Color.WhiteSmoke;
            this.iconPictureBox5.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox5.IconSize = 59;
            this.iconPictureBox5.Location = new System.Drawing.Point(0, -3);
            this.iconPictureBox5.Name = "iconPictureBox5";
            this.iconPictureBox5.Size = new System.Drawing.Size(59, 60);
            this.iconPictureBox5.TabIndex = 8;
            this.iconPictureBox5.TabStop = false;
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(22)))), ((int)(((byte)(22)))));
            this.panel12.Controls.Add(this.panel15);
            this.panel12.Controls.Add(this.panel14);
            this.panel12.Controls.Add(this.panel16);
            this.panel12.Controls.Add(this.panel17);
            this.panel12.Location = new System.Drawing.Point(294, 238);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(564, 228);
            this.panel12.TabIndex = 30;
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.panel15.Controls.Add(this.label7);
            this.panel15.Controls.Add(this.pictureBox3);
            this.panel15.Controls.Add(this.label4);
            this.panel15.Location = new System.Drawing.Point(0, 159);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(561, 48);
            this.panel15.TabIndex = 31;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Bahnschrift", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.MediumSlateBlue;
            this.label7.Location = new System.Drawing.Point(55, 10);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(162, 25);
            this.label7.TabIndex = 31;
            this.label7.Text = "gg/aUHs9tdbPm";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::VegasV2.Properties.Resources.VegasLogo;
            this.pictureBox3.Location = new System.Drawing.Point(0, 0);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(49, 48);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 30;
            this.pictureBox3.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Bahnschrift", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.MediumSlateBlue;
            this.label4.Location = new System.Drawing.Point(55, 10);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 25);
            this.label4.TabIndex = 9;
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.panel14.Controls.Add(this.pictureBox2);
            this.panel14.Controls.Add(this.label3);
            this.panel14.Location = new System.Drawing.Point(0, 105);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(561, 48);
            this.panel14.TabIndex = 31;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::VegasV2.Properties.Resources.VegasLogo;
            this.pictureBox2.Location = new System.Drawing.Point(0, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(49, 48);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 30;
            this.pictureBox2.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Bahnschrift", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.MediumSlateBlue;
            this.label3.Location = new System.Drawing.Point(55, 10);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(308, 25);
            this.label3.TabIndex = 9;
            this.label3.Text = "Orphic has also been upgraded!";
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.panel16.Controls.Add(this.pictureBox1);
            this.panel16.Controls.Add(this.label5);
            this.panel16.Location = new System.Drawing.Point(3, 51);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(561, 48);
            this.panel16.TabIndex = 28;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::VegasV2.Properties.Resources.VegasLogo;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(49, 48);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 30;
            this.pictureBox1.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Bahnschrift", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.MediumSlateBlue;
            this.label5.Location = new System.Drawing.Point(55, 10);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(206, 25);
            this.label5.TabIndex = 9;
            this.label5.Text = "Layer 7 is now fixed!";
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.panel17.Controls.Add(this.label6);
            this.panel17.Controls.Add(this.iconPictureBox14);
            this.panel17.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel17.Location = new System.Drawing.Point(0, 0);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(564, 45);
            this.panel17.TabIndex = 22;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Bahnschrift", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(59, 11);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(130, 25);
            this.label6.TabIndex = 9;
            this.label6.Text = "Latest News";
            // 
            // iconPictureBox14
            // 
            this.iconPictureBox14.BackColor = System.Drawing.Color.Transparent;
            this.iconPictureBox14.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.iconPictureBox14.IconChar = FontAwesome.Sharp.IconChar.Newspaper;
            this.iconPictureBox14.IconColor = System.Drawing.Color.WhiteSmoke;
            this.iconPictureBox14.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox14.IconSize = 59;
            this.iconPictureBox14.Location = new System.Drawing.Point(0, -2);
            this.iconPictureBox14.Name = "iconPictureBox14";
            this.iconPictureBox14.Size = new System.Drawing.Size(59, 60);
            this.iconPictureBox14.TabIndex = 8;
            this.iconPictureBox14.TabStop = false;
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::VegasV2.Properties.Resources._212197sdsed;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Controls.Add(this.panel12);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Name = "Home";
            this.Size = new System.Drawing.Size(876, 475);
            this.Load += new System.EventHandler(this.Home_Load);
            this.panel2.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox12)).EndInit();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox11)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox9)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.siticoneCirclePictureBox1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox4)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox13)).EndInit();
            this.panel8.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox3)).EndInit();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox2)).EndInit();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox1)).EndInit();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox5)).EndInit();
            this.panel12.ResumeLayout(false);
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox14)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label1;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox4;
        private Siticone.UI.WinForms.SiticoneCirclePictureBox siticoneCirclePictureBox1;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label uservip;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox12;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label usercons;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox11;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label userlevel;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox9;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label usertime;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox10;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label username;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox13;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Label apis;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox3;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label totalusers;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox2;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label activeapis;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox1;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Label label2;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox5;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Label label6;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox14;
    }
}
