﻿
namespace VegasV2
{
    partial class Register
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Register));
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties49 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties50 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties51 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties52 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties53 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties54 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties55 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties56 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties57 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties58 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties59 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties60 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties61 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties62 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties63 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties64 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            this.bunifuLabel1 = new Bunifu.UI.WinForms.BunifuLabel();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.emailTB = new Bunifu.UI.WinForms.BunifuTextBox();
            this.tokenTB = new Bunifu.UI.WinForms.BunifuTextBox();
            this.bunifuPanel1 = new Bunifu.UI.WinForms.BunifuPanel();
            this.label2 = new System.Windows.Forms.Label();
            this.iconPictureBox5 = new FontAwesome.Sharp.IconPictureBox();
            this.passTB = new Bunifu.UI.WinForms.BunifuTextBox();
            this.userTB = new Bunifu.UI.WinForms.BunifuTextBox();
            this.iconButton2 = new FontAwesome.Sharp.IconButton();
            this.iconButton1 = new FontAwesome.Sharp.IconButton();
            this.bunifuPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox5)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuLabel1
            // 
            this.bunifuLabel1.AllowParentOverrides = false;
            this.bunifuLabel1.AutoEllipsis = false;
            this.bunifuLabel1.CursorType = null;
            this.bunifuLabel1.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel1.ForeColor = System.Drawing.Color.Gray;
            this.bunifuLabel1.Location = new System.Drawing.Point(23, 81);
            this.bunifuLabel1.Name = "bunifuLabel1";
            this.bunifuLabel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel1.Size = new System.Drawing.Size(75, 19);
            this.bunifuLabel1.TabIndex = 151;
            this.bunifuLabel1.Text = "Username";
            this.bunifuLabel1.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel1.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Gray;
            this.label5.Location = new System.Drawing.Point(19, 154);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(81, 19);
            this.label5.TabIndex = 153;
            this.label5.Text = "Password";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gray;
            this.label1.Location = new System.Drawing.Point(19, 223);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 19);
            this.label1.TabIndex = 158;
            this.label1.Text = "Token";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Gray;
            this.label3.Location = new System.Drawing.Point(19, 292);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 19);
            this.label3.TabIndex = 160;
            this.label3.Text = "Email";
            // 
            // emailTB
            // 
            this.emailTB.AcceptsReturn = false;
            this.emailTB.AcceptsTab = false;
            this.emailTB.AnimationSpeed = 200;
            this.emailTB.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.emailTB.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.emailTB.AutoSizeHeight = true;
            this.emailTB.BackColor = System.Drawing.Color.Transparent;
            this.emailTB.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("emailTB.BackgroundImage")));
            this.emailTB.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.emailTB.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.emailTB.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.emailTB.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(18)))), ((int)(((byte)(30)))));
            this.emailTB.BorderRadius = 1;
            this.emailTB.BorderThickness = 1;
            this.emailTB.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.emailTB.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.emailTB.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.emailTB.DefaultText = "";
            this.emailTB.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.emailTB.ForeColor = System.Drawing.Color.White;
            this.emailTB.HideSelection = true;
            this.emailTB.IconLeft = null;
            this.emailTB.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.emailTB.IconPadding = 10;
            this.emailTB.IconRight = null;
            this.emailTB.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.emailTB.Lines = new string[0];
            this.emailTB.Location = new System.Drawing.Point(23, 314);
            this.emailTB.MaxLength = 32767;
            this.emailTB.MinimumSize = new System.Drawing.Size(1, 1);
            this.emailTB.Modified = false;
            this.emailTB.Multiline = false;
            this.emailTB.Name = "emailTB";
            stateProperties49.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties49.FillColor = System.Drawing.Color.Empty;
            stateProperties49.ForeColor = System.Drawing.Color.Empty;
            stateProperties49.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.emailTB.OnActiveState = stateProperties49;
            stateProperties50.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties50.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties50.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties50.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.emailTB.OnDisabledState = stateProperties50;
            stateProperties51.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties51.FillColor = System.Drawing.Color.Empty;
            stateProperties51.ForeColor = System.Drawing.Color.Empty;
            stateProperties51.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.emailTB.OnHoverState = stateProperties51;
            stateProperties52.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(18)))), ((int)(((byte)(30)))));
            stateProperties52.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            stateProperties52.ForeColor = System.Drawing.Color.White;
            stateProperties52.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.emailTB.OnIdleState = stateProperties52;
            this.emailTB.Padding = new System.Windows.Forms.Padding(3);
            this.emailTB.PasswordChar = '\0';
            this.emailTB.PlaceholderForeColor = System.Drawing.Color.Gray;
            this.emailTB.PlaceholderText = "";
            this.emailTB.ReadOnly = false;
            this.emailTB.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.emailTB.SelectedText = "";
            this.emailTB.SelectionLength = 0;
            this.emailTB.SelectionStart = 0;
            this.emailTB.ShortcutsEnabled = true;
            this.emailTB.Size = new System.Drawing.Size(395, 44);
            this.emailTB.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.emailTB.TabIndex = 159;
            this.emailTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.emailTB.TextMarginBottom = 0;
            this.emailTB.TextMarginLeft = 3;
            this.emailTB.TextMarginTop = 0;
            this.emailTB.TextPlaceholder = "";
            this.emailTB.UseSystemPasswordChar = false;
            this.emailTB.WordWrap = true;
            // 
            // tokenTB
            // 
            this.tokenTB.AcceptsReturn = false;
            this.tokenTB.AcceptsTab = false;
            this.tokenTB.AnimationSpeed = 200;
            this.tokenTB.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.tokenTB.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.tokenTB.AutoSizeHeight = true;
            this.tokenTB.BackColor = System.Drawing.Color.Transparent;
            this.tokenTB.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tokenTB.BackgroundImage")));
            this.tokenTB.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.tokenTB.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.tokenTB.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.tokenTB.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(18)))), ((int)(((byte)(30)))));
            this.tokenTB.BorderRadius = 1;
            this.tokenTB.BorderThickness = 1;
            this.tokenTB.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.tokenTB.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tokenTB.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.tokenTB.DefaultText = "";
            this.tokenTB.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.tokenTB.ForeColor = System.Drawing.Color.White;
            this.tokenTB.HideSelection = true;
            this.tokenTB.IconLeft = null;
            this.tokenTB.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.tokenTB.IconPadding = 10;
            this.tokenTB.IconRight = null;
            this.tokenTB.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.tokenTB.Lines = new string[0];
            this.tokenTB.Location = new System.Drawing.Point(23, 245);
            this.tokenTB.MaxLength = 32767;
            this.tokenTB.MinimumSize = new System.Drawing.Size(1, 1);
            this.tokenTB.Modified = false;
            this.tokenTB.Multiline = false;
            this.tokenTB.Name = "tokenTB";
            stateProperties53.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties53.FillColor = System.Drawing.Color.Empty;
            stateProperties53.ForeColor = System.Drawing.Color.Empty;
            stateProperties53.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tokenTB.OnActiveState = stateProperties53;
            stateProperties54.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties54.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties54.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties54.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.tokenTB.OnDisabledState = stateProperties54;
            stateProperties55.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties55.FillColor = System.Drawing.Color.Empty;
            stateProperties55.ForeColor = System.Drawing.Color.Empty;
            stateProperties55.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tokenTB.OnHoverState = stateProperties55;
            stateProperties56.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(18)))), ((int)(((byte)(30)))));
            stateProperties56.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            stateProperties56.ForeColor = System.Drawing.Color.White;
            stateProperties56.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tokenTB.OnIdleState = stateProperties56;
            this.tokenTB.Padding = new System.Windows.Forms.Padding(3);
            this.tokenTB.PasswordChar = '\0';
            this.tokenTB.PlaceholderForeColor = System.Drawing.Color.Gray;
            this.tokenTB.PlaceholderText = "";
            this.tokenTB.ReadOnly = false;
            this.tokenTB.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tokenTB.SelectedText = "";
            this.tokenTB.SelectionLength = 0;
            this.tokenTB.SelectionStart = 0;
            this.tokenTB.ShortcutsEnabled = true;
            this.tokenTB.Size = new System.Drawing.Size(395, 44);
            this.tokenTB.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.tokenTB.TabIndex = 157;
            this.tokenTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tokenTB.TextMarginBottom = 0;
            this.tokenTB.TextMarginLeft = 3;
            this.tokenTB.TextMarginTop = 0;
            this.tokenTB.TextPlaceholder = "";
            this.tokenTB.UseSystemPasswordChar = false;
            this.tokenTB.WordWrap = true;
            // 
            // bunifuPanel1
            // 
            this.bunifuPanel1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuPanel1.BackgroundImage")));
            this.bunifuPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuPanel1.BorderColor = System.Drawing.Color.Transparent;
            this.bunifuPanel1.BorderRadius = 3;
            this.bunifuPanel1.BorderThickness = 1;
            this.bunifuPanel1.Controls.Add(this.label2);
            this.bunifuPanel1.Controls.Add(this.iconPictureBox5);
            this.bunifuPanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.bunifuPanel1.Location = new System.Drawing.Point(0, 0);
            this.bunifuPanel1.Name = "bunifuPanel1";
            this.bunifuPanel1.ShowBorders = true;
            this.bunifuPanel1.Size = new System.Drawing.Size(441, 51);
            this.bunifuPanel1.TabIndex = 152;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label2.Font = new System.Drawing.Font("Bahnschrift", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(59, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(91, 25);
            this.label2.TabIndex = 9;
            this.label2.Text = "Register";
            // 
            // iconPictureBox5
            // 
            this.iconPictureBox5.BackColor = System.Drawing.Color.Transparent;
            this.iconPictureBox5.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.iconPictureBox5.IconChar = FontAwesome.Sharp.IconChar.AddressCard;
            this.iconPictureBox5.IconColor = System.Drawing.Color.WhiteSmoke;
            this.iconPictureBox5.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPictureBox5.IconSize = 59;
            this.iconPictureBox5.Location = new System.Drawing.Point(0, 0);
            this.iconPictureBox5.Name = "iconPictureBox5";
            this.iconPictureBox5.Size = new System.Drawing.Size(59, 60);
            this.iconPictureBox5.TabIndex = 8;
            this.iconPictureBox5.TabStop = false;
            // 
            // passTB
            // 
            this.passTB.AcceptsReturn = false;
            this.passTB.AcceptsTab = false;
            this.passTB.AnimationSpeed = 200;
            this.passTB.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.passTB.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.passTB.AutoSizeHeight = true;
            this.passTB.BackColor = System.Drawing.Color.Transparent;
            this.passTB.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("passTB.BackgroundImage")));
            this.passTB.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.passTB.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.passTB.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.passTB.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(18)))), ((int)(((byte)(30)))));
            this.passTB.BorderRadius = 1;
            this.passTB.BorderThickness = 1;
            this.passTB.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.passTB.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.passTB.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.passTB.DefaultText = "";
            this.passTB.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.passTB.ForeColor = System.Drawing.Color.White;
            this.passTB.HideSelection = true;
            this.passTB.IconLeft = null;
            this.passTB.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.passTB.IconPadding = 10;
            this.passTB.IconRight = null;
            this.passTB.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.passTB.Lines = new string[0];
            this.passTB.Location = new System.Drawing.Point(23, 176);
            this.passTB.MaxLength = 32767;
            this.passTB.MinimumSize = new System.Drawing.Size(1, 1);
            this.passTB.Modified = false;
            this.passTB.Multiline = false;
            this.passTB.Name = "passTB";
            stateProperties57.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties57.FillColor = System.Drawing.Color.Empty;
            stateProperties57.ForeColor = System.Drawing.Color.Empty;
            stateProperties57.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.passTB.OnActiveState = stateProperties57;
            stateProperties58.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties58.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties58.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties58.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.passTB.OnDisabledState = stateProperties58;
            stateProperties59.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties59.FillColor = System.Drawing.Color.Empty;
            stateProperties59.ForeColor = System.Drawing.Color.Empty;
            stateProperties59.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.passTB.OnHoverState = stateProperties59;
            stateProperties60.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(18)))), ((int)(((byte)(30)))));
            stateProperties60.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            stateProperties60.ForeColor = System.Drawing.Color.White;
            stateProperties60.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.passTB.OnIdleState = stateProperties60;
            this.passTB.Padding = new System.Windows.Forms.Padding(3);
            this.passTB.PasswordChar = '\0';
            this.passTB.PlaceholderForeColor = System.Drawing.Color.Gray;
            this.passTB.PlaceholderText = "";
            this.passTB.ReadOnly = false;
            this.passTB.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.passTB.SelectedText = "";
            this.passTB.SelectionLength = 0;
            this.passTB.SelectionStart = 0;
            this.passTB.ShortcutsEnabled = true;
            this.passTB.Size = new System.Drawing.Size(395, 44);
            this.passTB.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.passTB.TabIndex = 150;
            this.passTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.passTB.TextMarginBottom = 0;
            this.passTB.TextMarginLeft = 3;
            this.passTB.TextMarginTop = 0;
            this.passTB.TextPlaceholder = "";
            this.passTB.UseSystemPasswordChar = false;
            this.passTB.WordWrap = true;
            // 
            // userTB
            // 
            this.userTB.AcceptsReturn = false;
            this.userTB.AcceptsTab = false;
            this.userTB.AnimationSpeed = 200;
            this.userTB.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.userTB.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.userTB.AutoSizeHeight = true;
            this.userTB.BackColor = System.Drawing.Color.Transparent;
            this.userTB.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("userTB.BackgroundImage")));
            this.userTB.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.userTB.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.userTB.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.userTB.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(18)))), ((int)(((byte)(30)))));
            this.userTB.BorderRadius = 1;
            this.userTB.BorderThickness = 1;
            this.userTB.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.userTB.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.userTB.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.userTB.DefaultText = "";
            this.userTB.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.userTB.ForeColor = System.Drawing.Color.White;
            this.userTB.HideSelection = true;
            this.userTB.IconLeft = null;
            this.userTB.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.userTB.IconPadding = 10;
            this.userTB.IconRight = null;
            this.userTB.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.userTB.Lines = new string[0];
            this.userTB.Location = new System.Drawing.Point(23, 106);
            this.userTB.MaxLength = 32767;
            this.userTB.MinimumSize = new System.Drawing.Size(1, 1);
            this.userTB.Modified = false;
            this.userTB.Multiline = false;
            this.userTB.Name = "userTB";
            stateProperties61.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties61.FillColor = System.Drawing.Color.Empty;
            stateProperties61.ForeColor = System.Drawing.Color.Empty;
            stateProperties61.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.userTB.OnActiveState = stateProperties61;
            stateProperties62.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties62.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties62.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties62.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.userTB.OnDisabledState = stateProperties62;
            stateProperties63.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties63.FillColor = System.Drawing.Color.Empty;
            stateProperties63.ForeColor = System.Drawing.Color.Empty;
            stateProperties63.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.userTB.OnHoverState = stateProperties63;
            stateProperties64.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(18)))), ((int)(((byte)(30)))));
            stateProperties64.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            stateProperties64.ForeColor = System.Drawing.Color.White;
            stateProperties64.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.userTB.OnIdleState = stateProperties64;
            this.userTB.Padding = new System.Windows.Forms.Padding(3);
            this.userTB.PasswordChar = '\0';
            this.userTB.PlaceholderForeColor = System.Drawing.Color.Gray;
            this.userTB.PlaceholderText = "";
            this.userTB.ReadOnly = false;
            this.userTB.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.userTB.SelectedText = "";
            this.userTB.SelectionLength = 0;
            this.userTB.SelectionStart = 0;
            this.userTB.ShortcutsEnabled = true;
            this.userTB.Size = new System.Drawing.Size(395, 45);
            this.userTB.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.userTB.TabIndex = 149;
            this.userTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.userTB.TextMarginBottom = 0;
            this.userTB.TextMarginLeft = 3;
            this.userTB.TextMarginTop = 0;
            this.userTB.TextPlaceholder = "";
            this.userTB.UseSystemPasswordChar = false;
            this.userTB.WordWrap = true;
            // 
            // iconButton2
            // 
            this.iconButton2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.iconButton2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.iconButton2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.iconButton2.ForeColor = System.Drawing.Color.White;
            this.iconButton2.IconChar = FontAwesome.Sharp.IconChar.None;
            this.iconButton2.IconColor = System.Drawing.Color.Black;
            this.iconButton2.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton2.Location = new System.Drawing.Point(23, 383);
            this.iconButton2.Name = "iconButton2";
            this.iconButton2.Size = new System.Drawing.Size(395, 40);
            this.iconButton2.TabIndex = 155;
            this.iconButton2.Text = "Register";
            this.iconButton2.UseVisualStyleBackColor = false;
            this.iconButton2.Click += new System.EventHandler(this.iconButton2_Click);
            // 
            // iconButton1
            // 
            this.iconButton1.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.iconButton1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.iconButton1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.iconButton1.ForeColor = System.Drawing.Color.White;
            this.iconButton1.IconChar = FontAwesome.Sharp.IconChar.None;
            this.iconButton1.IconColor = System.Drawing.Color.Black;
            this.iconButton1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton1.Location = new System.Drawing.Point(23, 429);
            this.iconButton1.Name = "iconButton1";
            this.iconButton1.Size = new System.Drawing.Size(395, 40);
            this.iconButton1.TabIndex = 154;
            this.iconButton1.Text = "Login";
            this.iconButton1.UseVisualStyleBackColor = false;
            this.iconButton1.Click += new System.EventHandler(this.iconButton1_Click);
            // 
            // Register
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(22)))), ((int)(((byte)(22)))));
            this.ClientSize = new System.Drawing.Size(441, 508);
            this.Controls.Add(this.emailTB);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tokenTB);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.bunifuPanel1);
            this.Controls.Add(this.bunifuLabel1);
            this.Controls.Add(this.passTB);
            this.Controls.Add(this.userTB);
            this.Controls.Add(this.iconButton2);
            this.Controls.Add(this.iconButton1);
            this.Controls.Add(this.label5);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Register";
            this.Text = "Vegas";
            this.bunifuPanel1.ResumeLayout(false);
            this.bunifuPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPictureBox5)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.UI.WinForms.BunifuPanel bunifuPanel1;
        private System.Windows.Forms.Label label2;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox5;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel1;
        private Bunifu.UI.WinForms.BunifuTextBox passTB;
        private Bunifu.UI.WinForms.BunifuTextBox userTB;
        private FontAwesome.Sharp.IconButton iconButton2;
        private FontAwesome.Sharp.IconButton iconButton1;
        private System.Windows.Forms.Label label5;
        private Bunifu.UI.WinForms.BunifuTextBox tokenTB;
        private System.Windows.Forms.Label label1;
        private Bunifu.UI.WinForms.BunifuTextBox emailTB;
        private System.Windows.Forms.Label label3;
    }
}