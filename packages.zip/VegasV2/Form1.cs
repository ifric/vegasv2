﻿using SafeGuard;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using VegasV2.Properties;

namespace VegasV2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void iconButton1_Click(object sender, EventArgs e)
        {
            bool @checked = this.checkBox1.Checked;
            if (@checked)
            {
                Settings.Default.UserName = this.userTB.Text;
                Settings.Default.Password = this.passTB.Text;
                Settings.Default.Save();
            }
            bool flag = !this.checkBox1.Checked;
            if (flag)
            {
                Settings.Default.Save();
            }


            //ResponseInformation.loginresponse.Failure is a boolean, which will will be true if login failed
            ResponseInformation.loginresponse = ClientFunctions.Login(userTB.Text, passTB.Text, ProgramInformation.ProgramId);
            //Here we set password so we can use them throughout the application
            ResponseInformation.Password = passTB.Text;
            if (ResponseInformation.loginresponse.Failure)
            {
                //Message will be the reason for failed login
                MessageBox.Show(ResponseInformation.loginresponse.Message);
            }
            else
            {
                //Message will be "Successfully Logged In"

                MessageBox.Show(ResponseInformation.loginresponse.Message);
                this.Hide();
                Hub frmMain = new Hub();
                frmMain.ShowDialog();
                this.Close();
            }
        }

        private void iconButton2_Click(object sender, EventArgs e)
        {
            Register main = new Register();
            main.Show();
            this.Hide();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            bool flag = Settings.Default.UserName != "" || Settings.Default.UserName != string.Empty;
            if (flag)
            {
                this.userTB.Text = Settings.Default.UserName;
                this.passTB.Text = Settings.Default.Password;
            }
        }
    }
}
